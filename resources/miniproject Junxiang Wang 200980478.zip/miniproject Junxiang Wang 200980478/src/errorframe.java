/*
 * author : Junxiang Wang (王俊翔)
 * date : 2022.6.4
 * This file is for java miniproject.
 * */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class errorframe extends JFrame {
    public errorframe(){
        //创建容器
        //Create a container
        Container errorcontainer = this.getContentPane();

        //设置页面大小与布局
        //Set the page size and layout
        this.setBounds(500,400,380,200);
        this.setResizable(false);

        //创建组件
        //Create a component
        JPanel errorpanel = new JPanel();
        errorpanel.setBounds(50,0,300,200);
        errorpanel.setLayout(new GridLayout(2,1,0,0));
        JLabel errorlabel = new JLabel("This word is not in the word list!");
        Font errortextfont = new Font(Font.SERIF,Font.BOLD,26);
        errorlabel.setFont(errortextfont);
        JButton errorbutton = new JButton("ok");
        errorbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        //添加组件
        //Add components
        errorpanel.add(errorlabel);
        errorpanel.add(errorbutton);
        errorcontainer.add(errorpanel);

        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        this.setVisible(true);
    }
}
