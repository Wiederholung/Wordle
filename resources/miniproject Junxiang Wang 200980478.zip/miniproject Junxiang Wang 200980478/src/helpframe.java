/*
 * author : Junxiang Wang (王俊翔)
 * date : 2022.6.4
 * This file is for java miniproject.
 * */

import javax.swing.*;
import java.awt.*;

public class helpframe extends JFrame {
    public helpframe(){
        init();
    }

    //初始化帮助窗口
    //Initialize help window
    private void init(){

        //创建容器
        //Create container
        Container helpcontainer = this.getContentPane();

        //设置页面大小与布局
        //Set page size and layout
        this.setBounds(0,0,1500,800);
        this.setResizable(false);
        helpcontainer.setLayout(null);

        //创建panel
        //Create panel
        JPanel helpframepanel = new JPanel();
        helpframepanel.setBounds(0,0,1500,800);
        helpframepanel.setLayout(new GridLayout(9,1));

        //创建帮助页文本
        //Create help page text
        JLabel helptext1 = new JLabel("This page will tell you how to play it.");
        JLabel helptext2 = new JLabel("The author preset a five word word word.");
        JLabel helptext3 = new JLabel("You can guess by typing the letters A-Z on the keyboard.");
        JLabel helptext4 = new JLabel("When you have finished typing five letters, you can click enter to view the results.");
        JLabel helptext5 = new JLabel("The letter background turns green to indicate that there is this letter in the word and this letter is just in this position.");
        JLabel helptext6 = new JLabel("If the letter background turns yellow, it means that there is this letter in the word, but this letter is not in this position.");
        JLabel helptext7 = new JLabel("If the letter background turns gray, it means that there is no letter in the word.");
        JLabel helptext8 = new JLabel("You have six chances to guess the word.");
        JLabel helptext9 = new JLabel("If the input is wrong, you can press the delete key to delete.");
        Font helptextfont = new Font(Font.SERIF,Font.BOLD,24);
        helptext1.setFont(helptextfont);
        helptext1.setHorizontalAlignment(SwingConstants.CENTER);
        helptext1.setSize(1500,50);
        helptext2.setFont(helptextfont);
        helptext2.setHorizontalAlignment(SwingConstants.CENTER);
        helptext2.setSize(1500,50);
        helptext3.setFont(helptextfont);
        helptext3.setHorizontalAlignment(SwingConstants.CENTER);
        helptext3.setSize(1500,50);
        helptext4.setFont(helptextfont);
        helptext4.setHorizontalAlignment(SwingConstants.CENTER);
        helptext4.setSize(1500,50);
        helptext5.setFont(helptextfont);
        helptext5.setHorizontalAlignment(SwingConstants.CENTER);
        helptext5.setSize(1500,50);
        helptext6.setFont(helptextfont);
        helptext6.setHorizontalAlignment(SwingConstants.CENTER);
        helptext6.setSize(1500,50);
        helptext7.setFont(helptextfont);
        helptext7.setHorizontalAlignment(SwingConstants.CENTER);
        helptext7.setSize(1500,50);
        helptext8.setFont(helptextfont);
        helptext8.setHorizontalAlignment(SwingConstants.CENTER);
        helptext8.setSize(1500,50);
        helptext9.setFont(helptextfont);
        helptext9.setHorizontalAlignment(SwingConstants.CENTER);
        helptext9.setSize(1500,50);

        //添加部件并设置可见
        //Add parts and set visibility
        helpframepanel.add(helptext1);
        helpframepanel.add(helptext2);
        helpframepanel.add(helptext3);
        helpframepanel.add(helptext4);
        helpframepanel.add(helptext5);
        helpframepanel.add(helptext6);
        helpframepanel.add(helptext7);
        helpframepanel.add(helptext8);
        helpframepanel.add(helptext9);
        helpcontainer.add(helpframepanel);
        this.setVisible(true);
    }
}
