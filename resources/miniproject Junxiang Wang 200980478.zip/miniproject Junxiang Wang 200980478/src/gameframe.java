/*
* author : Junxiang Wang (王俊翔)
* date : 2022.6.4
* This file is for java miniproject.
* */

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class gameframe extends JFrame implements KeyListener{

    //单词总数
    //Total number of words
    private int totalwords = 501;

    //文件路径
    //The file path
    //"e:\\code\\MYJAVA\\foridea\\myidea\\lib\\data.txt"
    private String filepath = "..\\lib\\data.txt";


    //答案
    //answer
    private String[] myanswer = new String[5];

    //可更改的答案，用于比对与修改
    //Changeable answers for comparison and modification
    private String[] temanswer = new String[5];

    //存储对比结果 1：对位比对成功 2：错位比对成功 0：比对失败
    //Storage comparison result 1: Alignment successful 2: Misalignment successful 0: Comparison failed
    int result[][] = new int[6][5];

    //判断是否完成比对（准备上色）
    //Determine if the comparison is complete (ready to color)
    boolean isfinish[] = new boolean[5];

    //此处是否有内容
    //Is there content here
    private boolean[][] position = new boolean[6][5];

    //此处的内容
    //Content here
    public String[][] content = new String[6][5];

    //正在处理的位置
    //The location being processed

    private int Xindex = 1;
    private int Yindex = 1;

    //建立存放每行块的容器
    //Create a container for each row of blocks
    ArrayList<JLabel> row1 = new ArrayList<JLabel>();
    ArrayList<JLabel> row2 = new ArrayList<JLabel>();
    ArrayList<JLabel> row3 = new ArrayList<JLabel>();
    ArrayList<JLabel> row4 = new ArrayList<JLabel>();
    ArrayList<JLabel> row5 = new ArrayList<JLabel>();
    ArrayList<JLabel> row6 = new ArrayList<JLabel>();

    //建立存放行的容器
    //Establish containers for storage and release
    ArrayList<ArrayList<JLabel>> allrows = new ArrayList<ArrayList<JLabel>>();
    ArrayList<JPanel> rows = new ArrayList<JPanel>();



    public gameframe() {
        //初始化
        //initialization
        init();

    }

    public void init(){

        //获取目标单词
        //Get target word
        try {
            newwords();
        } catch (Exception e) {
            System.out.println("erorr");
        }


        //初始化比对结果
        //Initialize comparison results
        for (int i = 0 ; i < 6 ; i++){
            for (int j = 0 ; j < 5 ; j++){
                result[i][j] = 0;
            }
        }

        //初始化全部块为无内容
        //Initialize all blocks as no content
        for (int i = 0; i<6;i++){
            for (int j = 0; j<5;j++){
                position[i][j] = false;
            }
        }

        //创建容器
        //Create container
        Container gamecontainer = this.getContentPane();

        //创建panel
        //Create panel
        JPanel gamepagetop = new JPanel();
        JPanel gamepagemain = new JPanel(new GridLayout(6,1,0,10));
        JPanel gamepagemainrow1 = new JPanel(new GridLayout(1,5,10,0));
        JPanel gamepagemainrow2 = new JPanel(new GridLayout(1,5,10,0));
        JPanel gamepagemainrow3 = new JPanel(new GridLayout(1,5,10,0));
        JPanel gamepagemainrow4 = new JPanel(new GridLayout(1,5,10,0));
        JPanel gamepagemainrow5 = new JPanel(new GridLayout(1,5,10,0));
        JPanel gamepagemainrow6 = new JPanel(new GridLayout(1,5,10,0));

        //将每行的panel加入容器中方便之后批量添加
        //Add panels of each row to the container for batch addition
        rows.add(gamepagemainrow1);
        rows.add(gamepagemainrow2);
        rows.add(gamepagemainrow3);
        rows.add(gamepagemainrow4);
        rows.add(gamepagemainrow5);
        rows.add(gamepagemainrow6);

        //设置页面大小与布局
        //Set page size and layout
        this.setBounds(50,0,1000,800);
        this.setResizable(false);


        //创建标题
        //Create title
        JLabel gamepagetoplabel = new JLabel("Wordle");
        gamepagetoplabel.setHorizontalAlignment(SwingConstants.CENTER);
        Font gamepagetopfont = new Font(Font.SERIF,Font.BOLD,24);
        gamepagetoplabel.setFont(gamepagetopfont);

        //创建块的字体
        //Create font for block
        Font blockfont = new Font(Font.SERIF,Font.BOLD,36);

        //将每行加入大容器之中
        //Add each row to the large container
        allrows.add(row1);
        allrows.add(row2);
        allrows.add(row3);
        allrows.add(row4);
        allrows.add(row5);
        allrows.add(row6);

        //添加block
        //Add block
        for (int i = 0 ; i < 6 ; i++){
            for (int j = 0 ; j < 5 ; j++){
                JLabel temlabel = new JLabel();
                rows.get(i).add(temlabel);
                allrows.get(i).add(temlabel);
                allrows.get(i).get(j).setHorizontalAlignment(SwingConstants.CENTER);
                allrows.get(i).get(j).setOpaque(true);
                allrows.get(i).get(j).setFont(blockfont);
                allrows.get(i).get(j).setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY,5));
            }
        }

        //将每行加入页面
        //Add each row to the page
        gamepagemain.add(gamepagemainrow1);
        gamepagemain.add(gamepagemainrow2);
        gamepagemain.add(gamepagemainrow3);
        gamepagemain.add(gamepagemainrow4);
        gamepagemain.add(gamepagemainrow5);
        gamepagemain.add(gamepagemainrow6);



        //添加标签于panel
        //Add label to panel
        gamepagetop.add(gamepagetoplabel);

        //添加panel进容器
        //Add panel into container
        gamecontainer.add(gamepagetop,BorderLayout.NORTH);
        gamecontainer.add(gamepagemain,BorderLayout.CENTER);


        //获得焦点事件
        //Get focus event
        this.setFocusable(true);
        //获得键盘监听事件
        //Get keyboard listening events
        addKeyListener(this);

        //设置窗口关闭
        //Setting window close
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        //设置可见
        //Set visible
        this.setVisible(true);
    }

    private void newwords ()throws Exception{
        //提取单词
        //Extract words
        String line = "null";
        BufferedReader myreader = new BufferedReader(new FileReader(filepath));
        int myrandom = (int) (Math.random()*totalwords+1);
        for (int i = 1 ; i <= myrandom ; i++){
            line = myreader.readLine();
        }
        System.out.println(line);

        //设置答案
        //Set answer
        for (int i = 0 ; i < 5 ; i++){
            myanswer[i] = String.valueOf(line.charAt(i));
        }
//        myanswer[0] = "a";
//        myanswer[1] = "b";
//        myanswer[2] = "o";
//        myanswer[3] = "v";
//        myanswer[4] = "e";
        myreader.close();
    }


    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        //键盘获取的内容
        //Set the content obtained by the answer keyboard
        String charkeycode = String.valueOf(e.getKeyChar());
        int intkeycode = e.getKeyCode();

        //输入字符
        //Input character
        if (intkeycode >= KeyEvent.VK_A && intkeycode <= KeyEvent.VK_Z) {
            if (Xindex < 6) {
                //加入内容
                //Add content
                allrows.get(Yindex - 1).get(Xindex - 1).setText(charkeycode);
                //记录内容
                //Record content
                content[Yindex - 1][Xindex - 1] = charkeycode;
                position[Yindex - 1][Xindex - 1] = true;

                System.out.println(content[Yindex - 1][Xindex - 1]);

                //移动指针
                //Move pointer
                Xindex++;
            }

        }

        //按回车
        //Press enter
        if (intkeycode == KeyEvent.VK_ENTER){
            boolean compareresult = false;
            //判断是否在行尾
            //Judge whether it is at the end of the line
            if (Xindex == 6){
                try {
                    compareresult = isaword();
                } catch (Exception ex) {
                    System.out.println("error");
                }
                if (compareresult) {
                    //拷贝一份答案用于编辑
                    //Copy an answer for editing
                    for (int i = 0; i < 5; i++) {
                        temanswer[i] = myanswer[i];
                    }
                    for (int i = 1; i < 6; i++) {
                        //对位比对
                        //Contraposition comparison
                        if (content[Yindex - 1][i - 1].equals(temanswer[i - 1])) {
                            result[Yindex - 1][i - 1] = 1;
                            isfinish[i - 1] = true;
                            temanswer[i - 1] = "#";
                        }
                    }
                    //错位比对
                    //Dislocation comparison
                    for (int i = 1; i < 6; i++) {
                        for (int j = 1; j < 6; j++) {
                            if (!isfinish[i - 1]) {
                                if (content[Yindex - 1][i - 1].equals(temanswer[j - 1])) {
                                    result[Yindex - 1][i - 1] = 2;
                                    isfinish[i - 1] = true;
                                    temanswer[j - 1] = "#";
                                    break;
                                }
                            }
                        }
                    }
                    //依据比对结果上色
                    //Color according to the comparison results
                    for (int i = 1; i < 6; i++) {
                        System.out.println(result[Yindex - 1][i - 1]);
                        if (result[Yindex - 1][i - 1] == 2) {
                            allrows.get(Yindex - 1).get(i - 1).setBackground(Color.YELLOW);
                        } else if (result[Yindex - 1][i - 1] == 1) {
                            allrows.get(Yindex - 1).get(i - 1).setBackground(Color.GREEN);
                        } else if (result[Yindex - 1][i - 1] == 0) {
                            allrows.get(Yindex - 1).get(i - 1).setBackground(Color.GRAY);
                        }
                    }

                    //判断是否胜利
                    //Judge whether to win
                    boolean win = true;
                    for (int i = 0; i < 5; i++) {
                        if (result[Yindex - 1][i] != 1) {
                            win = false;
                            break;
                        }
                    }
                    //如果胜利
                    //If win
                    if (win) {
                        //胜利界面
                        //Victory interface
                        new resultdialog("win !", this);
                        System.out.println("win");
                    }
                    //如果失败
                    //If failed
                    if (Yindex == 6 && win == false) {
                        //失败界面
                        //Failure interface
                        new resultdialog("loose ! The right answer is " + myanswer[0] + myanswer[1] + myanswer[2] + myanswer[3] + myanswer[4], this);
                        System.out.println("flase");
                    }

                    //指针移动
                    //Pointer movement
                    Xindex = 1;
                    Yindex++;

                    //重置判断
                    //Reset judgment
                    for (int i = 0; i < 5; i++) {
                        temanswer[i] = myanswer[i];
                        isfinish[i] = false;
                    }
                }
                else {
                    new errordialog();
                }
            }
        }

        //按删除键
        //Press the delete key
        //intkeycode == KeyEvent.VK_DELETE
        if (intkeycode == KeyEvent.VK_BACK_SPACE){
            //判断是否可删除
            //Judge whether it can be deleted
            if (Xindex > 1) {
                if (position[Yindex - 1][Xindex - 2] == true) {
                    //删除内容
                    //Delete content
                    allrows.get(Yindex-1).get(Xindex-2).setText("");
                    Xindex --;
                    position[Yindex-1][Xindex-1] = false;
                    content[Yindex - 1][Xindex - 1] = "";
                }
            }
        }

    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    public void replay() {

        //新的获取目标单词
        //New get target word
        try {
            newwords();
        } catch (Exception e) {
            System.out.println("erorr");
        }

        //初始化指针
        //Initialize pointer
        Xindex = 1;
        Yindex = 1;

        //初始化比对结果
        //Initialize comparison results
        for (int i = 0 ; i < 6 ; i++){
            for (int j = 0 ; j < 5 ; j++){
                result[i][j] = 0;
            }
        }

        //初始化全部块为无内容
        //Initialize all blocks as no content
        for (int i = 0; i<6;i++){
            for (int j = 0; j<5;j++){
                position[i][j] = false;
            }
        }
        //初始化全部块内容为空
        //Initialize all block contents to be empty
        for (int i = 0; i<6;i++){
            for (int j = 0; j<5;j++){
                content[i][j] = "";
            }
        }

        //初始化显示内容
        //Initialize display
        for (int i = 0 ; i < 6 ; i++){
            for (int j = 0 ; j < 5 ; j++){
                allrows.get(i).get(j).setText("");
                allrows.get(i).get(j).setBackground(Color.WHITE);
            }
        }
    }

    private boolean isaword () throws Exception{
        boolean wordresult = false;
        boolean temresult = true;
        //提取单词
        //Extract words
        String temline = "null";
        BufferedReader temreader = new BufferedReader(new FileReader(filepath));
        //比对是否在单词表中
        //Whether the comparison is in the word list
        OUT:
        for (int i = 1 ; i <= totalwords ; i++){
            temline = temreader.readLine();
            for (int j = 0 ; j < 5 ; j++){
                //如果对比度字母大于目标字母则退出对比
                //If the contrast letter is greater than the target letter, exit the contrast
                if (j == 0 && ((content[Yindex - 1][0].compareTo(String.valueOf(temline.charAt(0))))<0) ){
                    break OUT;
                } else if (j == 1 && ((content[Yindex - 1][1].compareTo(String.valueOf(temline.charAt(1))))<0)) {
                    break OUT;
                } else if (j == 2 && ((content[Yindex - 1][2].compareTo(String.valueOf(temline.charAt(2))))<0)) {
                    break OUT;
                } else if (j == 3 && ((content[Yindex - 1][3].compareTo(String.valueOf(temline.charAt(3))))<0)) {
                    break OUT;
                } else if (j == 4 && ((content[Yindex - 1][4].compareTo(String.valueOf(temline.charAt(4))))<0)) {
                    break OUT;
                }else {
                    //如果一个字母对比不上就退出对比
                    //If a letter cannot be compared, exit the comparison
                    if (!(content[Yindex - 1][j].equals(String.valueOf(temline.charAt(j))))) {
                        temresult = false;
                        break;
                    }
                }
            }
            //对比成功
            //Comparison successful
            if (temresult){
                wordresult = true;
                break;
            }
            //重置对比
            //Reset comparison
            temresult = true;
        }
        temreader.close();
        return wordresult;
    }


    private class resultdialog extends JDialog {
        public resultdialog(String result,gameframe playgameframe){
            //打开结果窗口
            //Open results window
            super(new resultframe(result,playgameframe),"result",true);
        }
    }
    private class errordialog extends JDialog {
        public errordialog(){
            //打开错误窗口
            //Open error window
            super(new errorframe(),true);
        }
    }
}

