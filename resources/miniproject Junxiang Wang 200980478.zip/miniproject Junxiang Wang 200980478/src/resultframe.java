/*
 * author : Junxiang Wang (王俊翔)
 * date : 2022.6.4
 * This file is for java miniproject.
 * */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class resultframe extends JFrame {
    public resultframe(String result,gameframe playgameframe){
        //创建容器
        //Create container
        Container resultcontainer = this.getContentPane();

        //设置页面大小与布局
        //Set page size and layout
        this.setBounds(100,100,400,500);
        this.setResizable(false);

        //创建panel
        //Create panel

        JPanel resulttitle = new JPanel();
        JPanel resultmain = new JPanel();
        JPanel resultpanel = new JPanel();
        resultpanel.setLayout(null);
        resultmain.setBounds(50,50,300,300);
        resultmain.setLayout(new GridLayout(2,1,10,20));

        //创建标语
        //Create slogan
        JLabel resulttext = new JLabel(result);
        Font resulttextfont = new Font(Font.SERIF,Font.BOLD,26);
        resulttext.setFont(resulttextfont);
        resulttitle.add(resulttext);

        //添加按钮
        //add button
        JButton tryagainbutton = new JButton("play again");
        tryagainbutton.setSize(400,100);
        tryagainbutton.setFont(resulttextfont);
        JButton resultexistbutton = new JButton("exist");
        resultexistbutton.setSize(400,100);
        resultexistbutton.setFont(resulttextfont);
        resultmain.add(tryagainbutton);
        resultmain.add(resultexistbutton);

        //添加按钮监听器
        //Add button listener
        tryagainbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                playgameframe.replay();
                dispose();
            }
        });

        resultexistbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        //添加panel
        //Add panel
        resultcontainer.add(resulttitle,BorderLayout.NORTH);
        resultcontainer.add(resultpanel,BorderLayout.CENTER);
        resultpanel.add(resultmain);

        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        this.setVisible(true);
    }
}
