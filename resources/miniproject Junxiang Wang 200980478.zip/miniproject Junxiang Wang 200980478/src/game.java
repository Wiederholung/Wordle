/*
 * author : Junxiang Wang (王俊翔)
 * date : 2022.6.4
 * This file is for java miniproject.
 * */

public class game {
    public static void main(String[] args) {
        //开始游戏
        //Start the game
        new startmenu();
    }
}
