/*
 * author : Junxiang Wang (王俊翔)
 * date : 2022.6.4
 * This file is for java miniproject.
 * */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class startmenu extends JFrame {


    public startmenu(){
        init();
    }


    //初始化开始菜单
    //Initialize start menu
    private void init(){

        //创建容器
        //Create container
        Container startcontainer = this.getContentPane();

        //设置菜单大小
        //Set menu size
        this.setBounds(50,50,600,700);
        this.setTitle("welcome to wordle !");
        this.setResizable(false);

        //设置布局
        //Set layout
        startcontainer.setLayout(null);

        //设置关闭方法
        //Set closing method
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        //建立panel
        //Create panel
        JPanel startmenupanel = new JPanel();
        startmenupanel.setBounds(100,50,400,600);
        startmenupanel.setLayout(new GridLayout(4,1,20,20));
        startmenupanel.setVisible(true);

        //创建开始菜单按钮
        //设置开始按钮
        //Create start menu button
        //Set start button
        JButton startbutton = new JButton("start the game ");
        startbutton.setForeground(Color.GREEN);
        Font startbuttonfont = new Font(Font.SERIF,Font.BOLD,28);
        startbutton.setFont(startbuttonfont);
        //设置帮助按钮
        //Set help button
        JButton helpbutton = new JButton("help");
        helpbutton.setForeground(Color.ORANGE);
        Font helpbuttonfont = new Font(Font.SERIF,Font.BOLD,28);
        helpbutton.setFont(helpbuttonfont);
        //设置退出按钮
        //Set exit button
        JButton existbutton = new JButton("exsit the game");
        existbutton.setForeground(Color.BLACK);
        Font existbuttonfont = new Font(Font.SERIF,Font.BOLD,28);
        existbutton.setFont(existbuttonfont);

        //开始菜单标题
        //Start menu title
        JLabel welcomelabel = new JLabel("WELCOME TO WORDLE !");
        welcomelabel.setHorizontalAlignment(SwingConstants.CENTER);
        Font welcomelabelfont = new Font(Font.SERIF,Font.BOLD,24);
        welcomelabel.setFont(welcomelabelfont);

        //设置帮助按钮的监听器，打开一个新的帮助窗口
        //Set the listener for the help button to open a new help window
        helpbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new helpDialog();
            }
        });

        //设置退出按钮的监听器
        //Set listener for exit button
        existbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
                dispose();
            }
        });

        //设置开始按钮的监听器
        //Set listener for start button
        startbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new startDialog();
                dispose();
            }
        });

        //将部件添加
        //Add part to
        startmenupanel.add(welcomelabel);
        startmenupanel.add(startbutton);
        startmenupanel.add(helpbutton);
        startmenupanel.add(existbutton);

        startcontainer.add(startmenupanel);

        //设置可见
        //Set visible
        this.setVisible(true);



        }


    private class startDialog extends JDialog {

        //新建游戏窗口
        public startDialog(){
            super(new gameframe(),"game",true);
        }

    }

    private class helpDialog extends JDialog {
        public helpDialog(){
            //新建帮助窗口
            super(new helpframe(),"help",true);

        }
    }


}
