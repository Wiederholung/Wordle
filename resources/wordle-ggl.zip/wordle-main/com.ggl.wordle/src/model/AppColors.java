package com.ggl.wordle.model;

import java.awt.Color;

public class AppColors {
	
	public static Color GRAY = new Color(120, 124, 126);
	public static Color GREEN = new Color(106, 170, 100);
	public static Color YELLOW = new Color(201, 180, 88);
	
	public static Color OUTLINE = new Color(211, 214, 218);

}
