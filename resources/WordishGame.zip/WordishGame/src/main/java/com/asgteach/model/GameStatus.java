
package com.asgteach.model;

import com.asgteach.modelview.LetterStyle;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class GameStatus {
    
    private static GameStatus instance = null;
    
    private List<LetterState> letterStateList = new ArrayList<>();
    private Map<String, LetterStyle.DisplayType> state = new HashMap<>();
    private final WordStats wordStats = new WordStats();
    
    private GameStatus() {}
    
    public static GameStatus getInstance() {
        if (instance == null) {
            instance = new GameStatus();
        }
        return instance;
    }

    public List<LetterState> getLetterState() {
        return letterStateList;
    }

    public Map<String, LetterStyle.DisplayType> getKeyBoardState() {
        return state;
    }
    
    public WordStats getWordStats() {
        return this.wordStats;
    }

    public void setLetterState(List<LetterState> letterState) {
        this.letterStateList = letterState;
    }

    public void setKeyBoardState(Map<String, LetterStyle.DisplayType> keyBoardState) {
        this.state = keyBoardState;
    }
       
}


