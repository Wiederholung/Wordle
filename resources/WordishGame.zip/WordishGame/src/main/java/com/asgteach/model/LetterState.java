package com.asgteach.model;

import com.asgteach.modelview.LetterStyle.DisplayType;

public record LetterState(DisplayType displayType, String letter) {
    
}
